const express= require("express");
const path= require("path");
const fs= require("fs")
require("dotenv").config();
const app= express();
app.use(express.static(path.join(__dirname, "public")));
app.get("/public", (req,res)=>{
    res.status(200).sendFile(path.join(__dirname, "index.html"))
})
app.get("/public/page1", (req,res)=>{
    res.status(200).sendFile(path.join(__dirname, "page1.html"))
})
app.get("/public/page1", (req,res)=>{
    res.status(200).sendFile(path.join(__dirname, "page2.html"))
})
app.post("/json", (req, res) => {
    res.status(200).sendFile(path.join(__dirname, "webform.json"))
})
const port= process.env.PORT;
app.listen(port, ()=> {
    console.log("the app is listining port" +port);
})